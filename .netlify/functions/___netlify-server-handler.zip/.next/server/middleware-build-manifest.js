globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/oG4W3Qc-CLnHb3fCGEzwQ/_buildManifest.js",
    "static/oG4W3Qc-CLnHb3fCGEzwQ/_ssgManifest.js",
    "static/oG4W3Qc-CLnHb3fCGEzwQ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/0-~o727nja1lo.js",
    "static/chunks/10~x95jhs6ns3.js",
    "static/chunks/00nlt7x_9mi4z.js",
    "static/chunks/0usj8uycfz8~2.js",
    "static/chunks/turbopack-0cc3pg77jf~.k.js"
  ]
};
